# Model modules for fine-tuning and inference
