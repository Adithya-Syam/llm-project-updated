# Legal LLM Fine-tuning and RAG System
__version__ = "1.0.0"
